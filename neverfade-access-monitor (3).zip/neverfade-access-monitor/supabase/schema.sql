-- Supabase Schema for NeverFade Access Monitor
-- Run this in Supabase SQL Editor

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Drop existing tables (careful in production!)
DROP TABLE IF EXISTS reminders CASCADE;
DROP TABLE IF EXISTS access_cards CASCADE;
DROP TABLE IF EXISTS personnel CASCADE;
DROP TABLE IF EXISTS spk CASCADE;
DROP TABLE IF EXISTS companies CASCADE;
DROP TABLE IF EXISTS users CASCADE;
DROP TABLE IF EXISTS import_logs CASCADE;

-- Users table (managed by Supabase Auth, but we store roles here)
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('SUPER_ADMIN', 'ADMIN_VENDOR', 'SECURITY', 'SHE')),
    avatar TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Companies/Vendors
CREATE TABLE companies (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT UNIQUE NOT NULL,
    pic_name TEXT NOT NULL,
    phone TEXT NOT NULL,
    email TEXT,
    address TEXT,
    work_area TEXT,
    work_type TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- SPK / SHE Data
CREATE TABLE spk (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    spk_number TEXT UNIQUE NOT NULL,
    she_letter_number TEXT NOT NULL,
    she_letter_file TEXT,
    vendor_name TEXT NOT NULL,
    company_id UUID REFERENCES companies(id) ON DELETE SET NULL,
    work_area TEXT NOT NULL,
    work_type TEXT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    duration_days INT GENERATED ALWAYS AS (end_date - start_date) STORED,
    status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'FINISHED', 'EXPIRED')),
    notes TEXT,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Personnel
CREATE TABLE personnel (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    nik TEXT NOT NULL,
    position TEXT NOT NULL,
    photo TEXT,
    phone TEXT,
    email TEXT,
    company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
    spk_id UUID REFERENCES spk(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(nik, spk_id)
);

-- Access Cards
CREATE TABLE access_cards (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    card_number TEXT UNIQUE NOT NULL,
    qr_code TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'WARNING', 'EXPIRED', 'DISABLED')),
    issue_date DATE DEFAULT CURRENT_DATE,
    expiry_date DATE NOT NULL,
    disabled_at TIMESTAMPTZ,
    disabled_by UUID REFERENCES users(id),
    disable_reason TEXT,
    personnel_id UUID UNIQUE REFERENCES personnel(id) ON DELETE CASCADE,
    spk_id UUID REFERENCES spk(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Reminders
CREATE TABLE reminders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    type TEXT NOT NULL CHECK (type IN ('H14', 'H7', 'H3', 'H1', 'EXPIRED')),
    scheduled_at DATE NOT NULL,
    sent_at TIMESTAMPTZ,
    is_read BOOLEAN DEFAULT FALSE,
    message TEXT NOT NULL,
    card_id UUID REFERENCES access_cards(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Import Logs
CREATE TABLE import_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    filename TEXT NOT NULL,
    total_rows INT NOT NULL,
    success_rows INT NOT NULL,
    error_rows INT NOT NULL,
    errors JSONB,
    imported_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX idx_spk_status ON spk(status);
CREATE INDEX idx_spk_end_date ON spk(end_date);
CREATE INDEX idx_spk_number ON spk(spk_number);
CREATE INDEX idx_personnel_nik ON personnel(nik);
CREATE INDEX idx_personnel_company ON personnel(company_id);
CREATE INDEX idx_cards_status ON access_cards(status);
CREATE INDEX idx_cards_expiry ON access_cards(expiry_date);
CREATE INDEX idx_cards_personnel ON access_cards(personnel_id);
CREATE INDEX idx_reminders_scheduled ON reminders(scheduled_at);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE companies ENABLE ROW LEVEL SECURITY;
ALTER TABLE spk ENABLE ROW LEVEL SECURITY;
ALTER TABLE personnel ENABLE ROW LEVEL SECURITY;
ALTER TABLE access_cards ENABLE ROW LEVEL SECURITY;
ALTER TABLE reminders ENABLE ROW LEVEL SECURITY;
ALTER TABLE import_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies (simplified for MVP - allow all authenticated)
CREATE POLICY "Allow all authenticated" ON users FOR ALL TO authenticated USING (true);
CREATE POLICY "Allow all authenticated" ON companies FOR ALL TO authenticated USING (true);
CREATE POLICY "Allow all authenticated" ON spk FOR ALL TO authenticated USING (true);
CREATE POLICY "Allow all authenticated" ON personnel FOR ALL TO authenticated USING (true);
CREATE POLICY "Allow all authenticated" ON access_cards FOR ALL TO authenticated USING (true);
CREATE POLICY "Allow all authenticated" ON reminders FOR ALL TO authenticated USING (true);
CREATE POLICY "Allow all authenticated" ON import_logs FOR ALL TO authenticated USING (true);

-- Function to auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_companies_updated_at BEFORE UPDATE ON companies FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_spk_updated_at BEFORE UPDATE ON spk FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_personnel_updated_at BEFORE UPDATE ON personnel FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to auto-create access card after personnel insert
CREATE OR REPLACE FUNCTION create_access_card()
RETURNS TRIGGER AS $$
DECLARE
    spk_record RECORD;
    new_card_number TEXT;
    existing_max INT;
BEGIN
    -- Get SPK data
    SELECT * INTO spk_record FROM spk WHERE id = NEW.spk_id;

    -- Generate card number (format: NF-XXXX)
    SELECT COALESCE(MAX(CAST(SUBSTRING(card_number FROM 4) AS INT)), 1000) INTO existing_max FROM access_cards;
    new_card_number := 'NF-' || (existing_max + 1);

    -- Insert access card
    INSERT INTO access_cards (card_number, qr_code, status, expiry_date, personnel_id, spk_id)
    VALUES (
        new_card_number,
        'QR-' || new_card_number || '-' || NEW.nik,
        'ACTIVE',
        spk_record.end_date,
        NEW.id,
        NEW.spk_id
    );

    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER after_personnel_insert AFTER INSERT ON personnel FOR EACH ROW EXECUTE FUNCTION create_access_card();

-- Insert sample data
INSERT INTO users (id, email, name, role) VALUES 
('00000000-0000-0000-0000-000000000001', 'admin@neverfade.com', 'Super Admin', 'SUPER_ADMIN'),
('00000000-0000-0000-0000-000000000002', 'she@neverfade.com', 'SHE Officer', 'SHE'),
('00000000-0000-0000-0000-000000000003', 'security@neverfade.com', 'Security', 'SECURITY');

INSERT INTO companies (id, name, pic_name, phone, work_area, work_type) VALUES
('11111111-1111-1111-1111-111111111111', 'PT ABC Sejahtera', 'Budi Santoso', '08123456789', 'Area A1-A2', 'Pemeliharaan'),
('11111111-1111-1111-1111-111111111112', 'PT XYZ Mandiri', 'Ahmad Wijaya', '08234567890', 'Area B3', 'Konstruksi');

INSERT INTO spk (id, spk_number, she_letter_number, vendor_name, company_id, work_area, work_type, start_date, end_date, status, created_by) VALUES
('22222222-2222-2222-2222-222222222221', '7600133734', 'SHE/2026/001', 'PT ABC Sejahtera', '11111111-1111-1111-1111-111111111111', 'Area A1-A2', 'Pemeliharaan', '2026-06-01', '2026-06-28', 'ACTIVE', '00000000-0000-0000-0000-000000000001'),
('22222222-2222-2222-2222-222222222222', '7600133999', 'SHE/2026/002', 'PT XYZ Mandiri', '11111111-1111-1111-1111-111111111112', 'Area B3', 'Konstruksi', '2026-06-15', '2026-07-15', 'ACTIVE', '00000000-0000-0000-0000-000000000001');

INSERT INTO personnel (id, name, nik, position, company_id, spk_id) VALUES
('33333333-3333-3333-3333-333333333331', 'Ahmad Fauzi', '3175091234560001', 'Teknisi', '11111111-1111-1111-1111-111111111111', '22222222-2222-2222-2222-222222222221'),
('33333333-3333-3333-3333-333333333332', 'Budi Raharjo', '3175091234560002', 'Supervisor', '11111111-1111-1111-1111-111111111111', '22222222-2222-2222-2222-222222222221'),
('33333333-3333-3333-3333-333333333333', 'Citra Lestari', '3175091234560003', 'Staff Safety', '11111111-1111-1111-1111-111111111112', '22222222-2222-2222-2222-222222222222');
