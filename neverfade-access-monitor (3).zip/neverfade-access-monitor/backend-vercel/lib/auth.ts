import jwt from 'jsonwebtoken';
import { NextApiRequest, NextApiResponse } from 'next';

const JWT_SECRET = process.env.JWT_SECRET || 'neverfade-secret';

export interface AuthUser {
  id: string;
  email: string;
  role: string;
  name: string;
}

export function verifyToken(req: NextApiRequest): AuthUser | null {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) return null;
    return jwt.verify(token, JWT_SECRET) as AuthUser;
  } catch {
    return null;
  }
}

export function requireAuth(handler: any) {
  return async (req: NextApiRequest, res: NextApiResponse) => {
    const user = verifyToken(req);
    if (!user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    (req as any).user = user;
    return handler(req, res);
  };
}

export function requireRole(roles: string[]) {
  return (handler: any) => {
    return async (req: NextApiRequest, res: NextApiResponse) => {
      const user = verifyToken(req);
      if (!user) return res.status(401).json({ error: 'Unauthorized' });
      if (!roles.includes(user.role)) {
        return res.status(403).json({ error: 'Forbidden - Insufficient role' });
      }
      (req as any).user = user;
      return handler(req, res);
    };
  };
}

export function generateToken(user: AuthUser): string {
  return jwt.sign(user, JWT_SECRET, { expiresIn: '7d' });
}
