import { ZodError } from 'zod';

export function handleError(res: any, error: unknown) {
  console.error('API Error:', error);
  if (error instanceof ZodError) {
    return res.status(400).json({ error: 'Validation failed', details: error.errors });
  }
  if (error instanceof Error) {
    return res.status(500).json({ error: error.message });
  }
  return res.status(500).json({ error: 'Internal server error' });
}

export function formatDate(date: string | Date): string {
  return new Date(date).toISOString().split('T')[0];
}

export function calculateDaysUntil(date: string | Date): number {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const target = new Date(date);
  target.setHours(0, 0, 0, 0);
  const diff = target.getTime() - today.getTime();
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}
