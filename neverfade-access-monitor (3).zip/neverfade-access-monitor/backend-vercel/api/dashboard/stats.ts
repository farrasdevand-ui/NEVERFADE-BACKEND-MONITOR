import type { NextApiRequest, NextApiResponse } from 'next';
import { supabase } from '@/lib/supabase';
import { requireAuth } from '@/lib/auth';
import { calculateDaysUntil } from '@/lib/utils';

async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const today = new Date().toISOString().split('T')[0];
    const date14 = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const date7 = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const date3 = new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    // Total active vendors (SPK)
    const { count: totalActive } = await supabase
      .from('spk')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'ACTIVE');

    // Expired today
    const { count: expiredToday } = await supabase
      .from('access_cards')
      .select('*', { count: 'exact', head: true })
      .eq('expiry_date', today)
      .neq('status', 'DISABLED');

    // Expiring in 14 days
    const { count: expiring14 } = await supabase
      .from('access_cards')
      .select('*', { count: 'exact', head: true })
      .lte('expiry_date', date14)
      .gte('expiry_date', today)
      .eq('status', 'ACTIVE');

    // Expiring in 7 days
    const { count: expiring7 } = await supabase
      .from('access_cards')
      .select('*', { count: 'exact', head: true })
      .lte('expiry_date', date7)
      .gte('expiry_date', today)
      .eq('status', 'ACTIVE');

    // Expiring in 3 days
    const { count: expiring3 } = await supabase
      .from('access_cards')
      .select('*', { count: 'exact', head: true })
      .lte('expiry_date', date3)
      .gte('expiry_date', today)
      .eq('status', 'ACTIVE');

    // To disable today
    const { count: toDisable } = await supabase
      .from('access_cards')
      .select('*', { count: 'exact', head: true })
      .lt('expiry_date', today)
      .neq('status', 'DISABLED');

    return res.status(200).json({
      totalActive: totalActive || 0,
      expiredToday: expiredToday || 0,
      expiring14: expiring14 || 0,
      expiring7: expiring7 || 0,
      expiring3: expiring3 || 0,
      toDisable: toDisable || 0,
    });
  } catch (error) {
    return res.status(500).json({ error: 'Failed to fetch stats' });
  }
}

export default requireAuth(handler);
