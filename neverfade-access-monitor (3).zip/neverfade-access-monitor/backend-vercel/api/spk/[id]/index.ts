import type { NextApiRequest, NextApiResponse } from 'next';
import { supabase } from '@/lib/supabase';
import { requireAuth } from '@/lib/auth';

async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { id } = req.query;

  if (req.method === 'GET') {
    try {
      const { data, error } = await supabase
        .from('spk')
        .select('*, companies(*), personnel(*, access_cards(*))')
        .eq('id', id)
        .single();

      if (error) throw error;
      return res.status(200).json({ data });
    } catch (error) {
      return res.status(500).json({ error: 'Failed to fetch SPK detail' });
    }
  }

  if (req.method === 'PUT') {
    try {
      const { data, error } = await supabase
        .from('spk')
        .update(req.body)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return res.status(200).json({ data });
    } catch (error) {
      return res.status(500).json({ error: 'Failed to update SPK' });
    }
  }

  if (req.method === 'DELETE') {
    try {
      const { error } = await supabase.from('spk').delete().eq('id', id);
      if (error) throw error;
      return res.status(204).end();
    } catch (error) {
      return res.status(500).json({ error: 'Failed to delete SPK' });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
}

export default requireAuth(handler);
