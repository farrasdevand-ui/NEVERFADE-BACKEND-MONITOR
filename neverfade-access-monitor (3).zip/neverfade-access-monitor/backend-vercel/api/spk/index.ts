import type { NextApiRequest, NextApiResponse } from 'next';
import { supabase } from '@/lib/supabase';
import { requireAuth } from '@/lib/auth';

async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      const { status, vendor, search, start_date, end_date } = req.query;

      let query = supabase.from('spk').select('*, companies(name), personnel(count)');

      if (status) query = query.eq('status', status);
      if (vendor) query = query.ilike('vendor_name', `%${vendor}%`);
      if (search) query = query.ilike('spk_number', `%${search}%`);
      if (start_date) query = query.gte('start_date', start_date);
      if (end_date) query = query.lte('end_date', end_date);

      const { data, error } = await query.order('created_at', { ascending: false });

      if (error) throw error;
      return res.status(200).json({ data });
    } catch (error) {
      return res.status(500).json({ error: 'Failed to fetch SPK' });
    }
  }

  if (req.method === 'POST') {
    try {
      const spk = req.body;
      const { data, error } = await supabase.from('spk').insert(spk).select().single();
      if (error) throw error;
      return res.status(201).json({ data });
    } catch (error) {
      return res.status(500).json({ error: 'Failed to create SPK' });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
}

export default requireAuth(handler);
