import type { NextApiRequest, NextApiResponse } from 'next';
import { supabase } from '@/lib/supabase';
import { requireAuth } from '@/lib/auth';

async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const today = new Date().toISOString().split('T')[0];

    const { data, error } = await supabase
      .from('access_cards')
      .select(`
        *,
        personnel(name, nik, position),
        spk(spk_number, vendor_name, end_date)
      `)
      .lt('expiry_date', today)
      .neq('status', 'DISABLED')
      .order('expiry_date', { ascending: true });

    if (error) throw error;
    return res.status(200).json({ data });
  } catch (error) {
    return res.status(500).json({ error: 'Failed to fetch cards to disable' });
  }
}

export default requireAuth(handler);
