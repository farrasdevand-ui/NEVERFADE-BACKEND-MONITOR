import type { NextApiRequest, NextApiResponse } from 'next';
import { supabase } from '@/lib/supabase';
import { requireAuth } from '@/lib/auth';

async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      const { status, search, expiring } = req.query;
      const today = new Date().toISOString().split('T')[0];

      let query = supabase.from('access_cards').select(`
        *,
        personnel(name, nik, position, photo),
        spk(spk_number, vendor_name, end_date)
      `);

      if (status) query = query.eq('status', status);
      if (search) query = query.or(`card_number.ilike.%${search}%,personnel.name.ilike.%${search}%`);

      if (expiring === 'true') {
        const date14 = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
        query = query.lte('expiry_date', date14).gte('expiry_date', today).neq('status', 'DISABLED');
      }

      const { data, error } = await query.order('expiry_date', { ascending: true });

      if (error) throw error;
      return res.status(200).json({ data });
    } catch (error) {
      return res.status(500).json({ error: 'Failed to fetch access cards' });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
}

export default requireAuth(handler);
