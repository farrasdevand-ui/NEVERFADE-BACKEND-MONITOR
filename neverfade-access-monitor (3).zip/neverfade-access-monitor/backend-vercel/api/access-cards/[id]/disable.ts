import type { NextApiRequest, NextApiResponse } from 'next';
import { supabase } from '@/lib/supabase';
import { requireAuth, requireRole } from '@/lib/auth';

const handler = async (req: NextApiRequest, res: NextApiResponse) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { id } = req.query;
    const { reason } = req.body;
    const user = (req as any).user;

    const { data, error } = await supabase
      .from('access_cards')
      .update({
        status: 'DISABLED',
        disabled_at: new Date().toISOString(),
        disabled_by: user.id,
        disable_reason: reason || 'Expired',
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return res.status(200).json({ data });
  } catch (error) {
    return res.status(500).json({ error: 'Failed to disable card' });
  }
};

export default requireRole(['SUPER_ADMIN', 'ADMIN_VENDOR', 'SECURITY'])(handler);
