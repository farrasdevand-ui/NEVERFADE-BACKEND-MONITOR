import type { NextApiRequest, NextApiResponse } from 'next';
import { supabase } from '@/lib/supabase';
import { requireAuth } from '@/lib/auth';
import * as XLSX from 'xlsx';

export const config = {
  api: {
    bodyParser: {
      sizeLimit: '10mb',
    },
  },
};

async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { file, spk_id, company_id } = req.body;

    if (!file || !spk_id || !company_id) {
      return res.status(400).json({ error: 'Missing file, spk_id, or company_id' });
    }

    // Decode base64 file
    const buffer = Buffer.from(file, 'base64');
    const workbook = XLSX.read(buffer, { type: 'buffer' });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(sheet);

    const errors: any[] = [];
    const validRows: any[] = [];
    const seenNik = new Set();

    // Validate
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i] as any;
      const rowNum = i + 2;

      if (!row['Nama'] || !row['NIK'] || !row['Jabatan']) {
        errors.push({ row: rowNum, error: 'Nama, NIK, atau Jabatan kosong' });
        continue;
      }

      if (seenNik.has(row['NIK'])) {
        errors.push({ row: rowNum, error: `NIK ${row['NIK']} duplikat dalam file` });
        continue;
      }
      seenNik.add(row['NIK']);

      // Check NIK in database
      const { data: existing } = await supabase
        .from('personnel')
        .select('id')
        .eq('nik', String(row['NIK']))
        .eq('spk_id', spk_id)
        .single();

      if (existing) {
        errors.push({ row: rowNum, error: `NIK ${row['NIK']} sudah ada di SPK ini` });
        continue;
      }

      validRows.push({
        name: row['Nama'],
        nik: String(row['NIK']),
        position: row['Jabatan'],
        phone: row['Telepon'] || null,
        email: row['Email'] || null,
        company_id,
        spk_id,
      });
    }

    if (validRows.length === 0) {
      return res.status(400).json({ 
        error: 'No valid rows to import', 
        total: rows.length, 
        success: 0, 
        errors 
      });
    }

    // Insert personnel (triggers will auto-create access cards)
    const { data: inserted, error: insertError } = await supabase
      .from('personnel')
      .insert(validRows)
      .select();

    if (insertError) throw insertError;

    // Log import
    await supabase.from('import_logs').insert({
      filename: 'import.xlsx',
      total_rows: rows.length,
      success_rows: validRows.length,
      error_rows: errors.length,
      errors: errors,
      imported_by: (req as any).user.id,
    });

    return res.status(200).json({
      total: rows.length,
      success: validRows.length,
      errors: errors.length,
      errorDetails: errors,
      data: inserted,
    });
  } catch (error: any) {
    console.error('Import error:', error);
    return res.status(500).json({ error: error.message || 'Import failed' });
  }
}

export default requireAuth(handler);
