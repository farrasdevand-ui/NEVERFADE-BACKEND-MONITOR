import type { NextApiRequest, NextApiResponse } from 'next';
import { supabase } from '@/lib/supabase';
import { requireAuth } from '@/lib/auth';

async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      const { company_id, spk_id, search } = req.query;

      let query = supabase.from('personnel').select('*, companies(name), spk(spk_number, end_date), access_cards(status, card_number, expiry_date)');

      if (company_id) query = query.eq('company_id', company_id);
      if (spk_id) query = query.eq('spk_id', spk_id);
      if (search) query = query.or(`name.ilike.%${search}%,nik.ilike.%${search}%`);

      const { data, error } = await query.order('created_at', { ascending: false });

      if (error) throw error;
      return res.status(200).json({ data });
    } catch (error) {
      return res.status(500).json({ error: 'Failed to fetch personnel' });
    }
  }

  if (req.method === 'POST') {
    try {
      const person = req.body;
      const { data, error } = await supabase.from('personnel').insert(person).select().single();
      if (error) throw error;
      return res.status(201).json({ data });
    } catch (error) {
      return res.status(500).json({ error: 'Failed to create personnel' });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
}

export default requireAuth(handler);
