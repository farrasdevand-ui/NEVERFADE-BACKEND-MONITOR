import { supabase } from '@/lib/supabase';

export default async function handler(req: any, res: any) {
  // Verify cron secret
  if (req.headers.authorization !== `Bearer ${process.env.CRON_SECRET}`) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const dates = {
      h14: new Date(today.getTime() + 14 * 24 * 60 * 60 * 1000),
      h7: new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000),
      h3: new Date(today.getTime() + 3 * 24 * 60 * 60 * 1000),
      h1: new Date(today.getTime() + 1 * 24 * 60 * 60 * 1000),
    };

    // Get all active cards with expiry dates
    const { data: cards, error } = await supabase
      .from('access_cards')
      .select('*, personnel(name), spk(vendor_name)')
      .eq('status', 'ACTIVE');

    if (error) throw error;

    let created = 0;

    for (const card of cards || []) {
      const expiry = new Date(card.expiry_date);
      expiry.setHours(0, 0, 0, 0);
      const diffDays = Math.ceil((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

      let reminderType = null;
      let message = '';

      if (diffDays === 14) {
        reminderType = 'H14';
        message = `Kartu akses ${card.personnel?.name} (SPK: ${card.spk?.vendor_name}) akan expired dalam 14 hari (${card.expiry_date})`;
      } else if (diffDays === 7) {
        reminderType = 'H7';
        message = `Kartu akses ${card.personnel?.name} akan expired dalam 7 hari (${card.expiry_date})`;
      } else if (diffDays === 3) {
        reminderType = 'H3';
        message = `URGENT: Kartu akses ${card.personnel?.name} akan expired dalam 3 hari (${card.expiry_date})`;
      } else if (diffDays === 1) {
        reminderType = 'H1';
        message = `CRITICAL: Kartu akses ${card.personnel?.name} expired BESOK (${card.expiry_date})`;
      } else if (diffDays <= 0) {
        reminderType = 'EXPIRED';
        message = `Kartu akses ${card.personnel?.name} sudah EXPIRED (${card.expiry_date}). Segera nonaktifkan!`;

        // Update card status to EXPIRED
        await supabase.from('access_cards').update({ status: 'EXPIRED' }).eq('id', card.id);
      }

      if (reminderType) {
        // Check if reminder already exists for today
        const { data: existing } = await supabase
          .from('reminders')
          .select('id')
          .eq('card_id', card.id)
          .eq('type', reminderType)
          .eq('scheduled_at', card.expiry_date)
          .single();

        if (!existing) {
          await supabase.from('reminders').insert({
            type: reminderType,
            scheduled_at: card.expiry_date,
            message,
            card_id: card.id,
          });
          created++;
        }
      }

      // Update card status to WARNING if H-7 or less
      if (diffDays <= 7 && diffDays > 0 && card.status === 'ACTIVE') {
        await supabase.from('access_cards').update({ status: 'WARNING' }).eq('id', card.id);
      }
    }

    return res.status(200).json({ 
      success: true, 
      remindersCreated: created,
      checked: cards?.length || 0 
    });
  } catch (error: any) {
    console.error('Cron error:', error);
    return res.status(500).json({ error: error.message });
  }
}
