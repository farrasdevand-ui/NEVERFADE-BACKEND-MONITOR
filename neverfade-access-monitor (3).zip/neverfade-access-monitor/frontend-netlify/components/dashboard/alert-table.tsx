'use client';

import { useEffect, useState } from 'react';
import { apiFetch } from '@/lib/api';
import { formatDate, getStatusColor, getStatusLabel, daysUntil } from '@/lib/utils';
import { AlertTriangle, Ban } from 'lucide-react';

interface AlertTableProps {
  type: 'to-disable' | 'expiring';
  title: string;
}

interface CardData {
  id: string;
  card_number: string;
  status: string;
  expiry_date: string;
  personnel: { name: string; nik: string };
  spk: { spk_number: string; vendor_name: string };
}

export default function AlertTable({ type, title }: AlertTableProps) {
  const [cards, setCards] = useState<CardData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const endpoint = type === 'to-disable' ? '/api/access-cards/to-disable' : '/api/access-cards?expiring=true';
    apiFetch(endpoint)
      .then((res) => setCards(res.data || []))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [type]);

  const handleDisable = async (id: string) => {
    if (!confirm('Yakin ingin menonaktifkan kartu ini?')) return;
    try {
      await apiFetch(`/api/access-cards/${id}/disable`, { method: 'POST' });
      setCards(cards.filter((c) => c.id !== id));
    } catch (err: any) {
      alert(err.message);
    }
  };

  if (loading) {
    return (
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-border p-6">
        <div className="animate-pulse h-4 bg-slate-200 dark:bg-slate-700 rounded w-1/3 mb-4" />
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="animate-pulse h-12 bg-slate-100 dark:bg-slate-800 rounded" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl border border-border overflow-hidden">
      <div className="p-4 border-b border-border flex items-center gap-2">
        <AlertTriangle className="w-5 h-5 text-amber-500" />
        <h3 className="font-semibold text-slate-900 dark:text-white">{title}</h3>
        <span className="ml-auto text-sm text-slate-500">{cards.length} items</span>
      </div>

      {cards.length === 0 ? (
        <div className="p-8 text-center text-slate-500 dark:text-slate-400">
          Tidak ada data
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 dark:bg-slate-800/50">
              <tr>
                <th className="px-4 py-3 text-left font-medium text-slate-600 dark:text-slate-400">Nama</th>
                <th className="px-4 py-3 text-left font-medium text-slate-600 dark:text-slate-400">Vendor</th>
                <th className="px-4 py-3 text-left font-medium text-slate-600 dark:text-slate-400">No Kartu</th>
                <th className="px-4 py-3 text-left font-medium text-slate-600 dark:text-slate-400">SPK</th>
                <th className="px-4 py-3 text-left font-medium text-slate-600 dark:text-slate-400">Expired</th>
                <th className="px-4 py-3 text-left font-medium text-slate-600 dark:text-slate-400">Status</th>
                {type === 'to-disable' && <th className="px-4 py-3 text-left font-medium text-slate-600 dark:text-slate-400">Aksi</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {cards.map((card) => (
                <tr key={card.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                  <td className="px-4 py-3 font-medium text-slate-900 dark:text-white">{card.personnel?.name}</td>
                  <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{card.spk?.vendor_name}</td>
                  <td className="px-4 py-3 font-mono text-slate-600 dark:text-slate-400">{card.card_number}</td>
                  <td className="px-4 py-3 font-mono text-slate-600 dark:text-slate-400">{card.spk?.spk_number}</td>
                  <td className="px-4 py-3">
                    <div className="flex flex-col">
                      <span className="text-slate-900 dark:text-white">{formatDate(card.expiry_date)}</span>
                      <span className="text-xs text-slate-500">
                        {daysUntil(card.expiry_date) <= 0 ? 'Hari ini' : `${daysUntil(card.expiry_date)} hari lagi`}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={getStatusColor(card.status)}>
                      {getStatusLabel(card.status)}
                    </span>
                  </td>
                  {type === 'to-disable' && (
                    <td className="px-4 py-3">
                      <button
                        onClick={() => handleDisable(card.id)}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-md text-xs font-medium bg-red-50 text-red-600 hover:bg-red-100 dark:bg-red-950/30 dark:text-red-400 dark:hover:bg-red-900/50 transition-colors"
                      >
                        <Ban className="w-3 h-3" />
                        Disable
                      </button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
