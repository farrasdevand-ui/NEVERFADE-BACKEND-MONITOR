'use client';

import { Moon, Sun, Bell, User } from 'lucide-react';
import { getUser } from '@/lib/api';

export default function Header({ darkMode, toggleDark }: { darkMode: boolean; toggleDark: () => void }) {
  const user = getUser();

  return (
    <header className="h-16 bg-white dark:bg-slate-900 border-b border-border flex items-center justify-between px-6">
      <div>
        <h2 className="text-sm font-semibold text-slate-500 dark:text-slate-400">
          Sistem Monitoring Vendor & Kartu Akses
        </h2>
      </div>
      <div className="flex items-center gap-4">
        <button
          onClick={toggleDark}
          className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
        </button>
        <button className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors relative">
          <Bell className="w-5 h-5" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full" />
        </button>
        <div className="flex items-center gap-3 pl-4 border-l border-border">
          <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center">
            <User className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          </div>
          <div className="hidden md:block">
            <p className="text-sm font-medium text-slate-900 dark:text-white">{user?.name || 'Admin'}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400">{user?.role || 'Admin'}</p>
          </div>
        </div>
      </div>
    </header>
  );
}
