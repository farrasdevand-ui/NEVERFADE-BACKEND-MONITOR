import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: string | Date): string {
  return new Date(date).toLocaleDateString('id-ID', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });
}

export function daysUntil(date: string | Date): number {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const target = new Date(date);
  target.setHours(0, 0, 0, 0);
  return Math.ceil((target.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

export function getStatusColor(status: string): string {
  switch (status) {
    case 'ACTIVE': return 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20';
    case 'WARNING': return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
    case 'EXPIRED': return 'bg-red-500/10 text-red-600 border-red-500/20';
    case 'DISABLED': return 'bg-slate-500/10 text-slate-600 border-slate-500/20';
    case 'FINISHED': return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
    default: return 'bg-gray-500/10 text-gray-600';
  }
}

export function getStatusLabel(status: string): string {
  switch (status) {
    case 'ACTIVE': return 'Aktif';
    case 'WARNING': return 'Peringatan';
    case 'EXPIRED': return 'Expired';
    case 'DISABLED': return 'Dinonaktifkan';
    case 'FINISHED': return 'Selesai';
    default: return status;
  }
}
