const API_URL = process.env.NEXT_PUBLIC_BACKEND_URL;

function getToken() {
  if (typeof window !== 'undefined') {
    return localStorage.getItem('nf_token');
  }
  return null;
}

export async function apiFetch(path: string, options: RequestInit = {}) {
  const token = getToken();
  const res = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  });

  if (res.status === 401) {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('nf_token');
      localStorage.removeItem('nf_user');
      window.location.href = '/login';
    }
  }

  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Request failed' }));
    throw new Error(err.error || 'Request failed');
  }

  return res.json();
}

export async function login(email: string, password: string) {
  const res = await fetch(`${API_URL}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });

  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Login failed');
  }

  const data = await res.json();
  if (typeof window !== 'undefined') {
    localStorage.setItem('nf_token', data.token);
    localStorage.setItem('nf_user', JSON.stringify(data.user));
  }
  return data;
}

export function logout() {
  if (typeof window !== 'undefined') {
    localStorage.removeItem('nf_token');
    localStorage.removeItem('nf_user');
    window.location.href = '/login';
  }
}

export function getUser() {
  if (typeof window !== 'undefined') {
    const raw = localStorage.getItem('nf_user');
    return raw ? JSON.parse(raw) : null;
  }
  return null;
}
