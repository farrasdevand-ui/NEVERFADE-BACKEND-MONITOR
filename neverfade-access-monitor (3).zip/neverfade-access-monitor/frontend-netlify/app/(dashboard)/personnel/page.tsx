'use client';

import { useEffect, useState, useCallback } from 'react';
import { apiFetch } from '@/lib/api';
import { formatDate, getStatusColor, getStatusLabel } from '@/lib/utils';
import { Plus, Search, Upload, Users } from 'lucide-react';
import Link from 'next/link';
import * as XLSX from 'xlsx';
import toast from 'react-hot-toast';

interface Personnel {
  id: string;
  name: string;
  nik: string;
  position: string;
  companies: { name: string };
  spk: { spk_number: string; end_date: string };
  access_cards: { card_number: string; status: string; expiry_date: string }[];
}

export default function PersonnelPage() {
  const [personnel, setPersonnel] = useState<Personnel[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [importing, setImporting] = useState(false);
  const [preview, setPreview] = useState<any[]>([]);
  const [showPreview, setShowPreview] = useState(false);
  const [spkId, setSpkId] = useState('');
  const [companyId, setCompanyId] = useState('');
  const [spks, setSpks] = useState<any[]>([]);
  const [companies, setCompanies] = useState<any[]>([]);

  useEffect(() => {
    fetchPersonnel();
    fetchMeta();
  }, [search]);

  const fetchPersonnel = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (search) params.append('search', search);
      const res = await apiFetch(`/api/personnel?${params.toString()}`);
      setPersonnel(res.data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const fetchMeta = async () => {
    try {
      const [spkRes, compRes] = await Promise.all([
        apiFetch('/api/spk'),
        apiFetch('/api/vendors'),
      ]);
      setSpks(spkRes.data || []);
      setCompanies(compRes.data || []);
    } catch (err) {
      console.error(err);
    }
  };

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      const bstr = evt.target?.result;
      const wb = XLSX.read(bstr, { type: 'binary' });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const data = XLSX.utils.sheet_to_json(ws);
      setPreview(data.slice(0, 10));
      setShowPreview(true);
    };
    reader.readAsBinaryString(file);
  };

  const handleImport = async () => {
    if (!spkId || !companyId) {
      toast.error('Pilih SPK dan Company terlebih dahulu');
      return;
    }
    const file = (document.getElementById('excel-file') as HTMLInputElement)?.files?.[0];
    if (!file) return;

    setImporting(true);
    try {
      const reader = new FileReader();
      reader.onload = async (evt) => {
        const base64 = btoa(evt.target?.result as string);
        const res = await apiFetch('/api/personnel/import', {
          method: 'POST',
          body: JSON.stringify({ file: base64, spk_id: spkId, company_id: companyId }),
        });
        toast.success(`Berhasil import ${res.success} personel`);
        setShowPreview(false);
        fetchPersonnel();
      };
      reader.readAsBinaryString(file);
    } catch (err: any) {
      toast.error(err.message || 'Import gagal');
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Data Personel Vendor</h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1">Kelola personel dan import dari Excel</p>
        </div>
        <div className="flex gap-2">
          <label className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-medium transition-colors cursor-pointer">
            <Upload className="w-4 h-4" />
            Import Excel
            <input id="excel-file" type="file" accept=".xlsx,.xls" className="hidden" onChange={handleFile} />
          </label>
          <button className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors">
            <Plus className="w-4 h-4" />
            Tambah
          </button>
        </div>
      </div>

      {showPreview && (
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-border p-6">
          <h3 className="font-semibold text-slate-900 dark:text-white mb-4">Preview Import (10 baris pertama)</h3>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <select
              value={spkId}
              onChange={(e) => setSpkId(e.target.value)}
              className="px-4 py-2 rounded-lg border border-input bg-background"
            >
              <option value="">Pilih SPK</option>
              {spks.map((s) => (
                <option key={s.id} value={s.id}>{s.spk_number} - {s.vendor_name}</option>
              ))}
            </select>
            <select
              value={companyId}
              onChange={(e) => setCompanyId(e.target.value)}
              className="px-4 py-2 rounded-lg border border-input bg-background"
            >
              <option value="">Pilih Vendor</option>
              {companies.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>
          <div className="overflow-x-auto mb-4">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 dark:bg-slate-800/50">
                <tr>
                  {Object.keys(preview[0] || {}).map((key) => (
                    <th key={key} className="px-3 py-2 text-left font-medium">{key}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {preview.map((row, i) => (
                  <tr key={i} className="border-t border-border">
                    {Object.values(row).map((val: any, j) => (
                      <td key={j} className="px-3 py-2">{String(val)}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex gap-2">
            <button
              onClick={handleImport}
              disabled={importing}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium disabled:opacity-50"
            >
              {importing ? 'Importing...' : 'Import Sekarang'}
            </button>
            <button
              onClick={() => setShowPreview(false)}
              className="px-4 py-2 border border-border rounded-lg font-medium hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              Batal
            </button>
          </div>
        </div>
      )}

      <div className="bg-white dark:bg-slate-900 rounded-xl border border-border overflow-hidden">
        <div className="p-4 border-b border-border">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Cari nama, NIK..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {loading ? (
          <div className="p-8 text-center text-slate-500">Memuat data...</div>
        ) : personnel.length === 0 ? (
          <div className="p-8 text-center text-slate-500 dark:text-slate-400">
            <Users className="w-12 h-12 mx-auto mb-3 text-slate-300" />
            <p>Tidak ada data personel</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 dark:bg-slate-800/50">
                <tr>
                  <th className="px-4 py-3 text-left font-medium text-slate-600 dark:text-slate-400">Nama</th>
                  <th className="px-4 py-3 text-left font-medium text-slate-600 dark:text-slate-400">NIK</th>
                  <th className="px-4 py-3 text-left font-medium text-slate-600 dark:text-slate-400">Jabatan</th>
                  <th className="px-4 py-3 text-left font-medium text-slate-600 dark:text-slate-400">Vendor</th>
                  <th className="px-4 py-3 text-left font-medium text-slate-600 dark:text-slate-400">SPK</th>
                  <th className="px-4 py-3 text-left font-medium text-slate-600 dark:text-slate-400">No Kartu</th>
                  <th className="px-4 py-3 text-left font-medium text-slate-600 dark:text-slate-400">Expired</th>
                  <th className="px-4 py-3 text-left font-medium text-slate-600 dark:text-slate-400">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {personnel.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="px-4 py-3 font-medium text-slate-900 dark:text-white">{p.name}</td>
                    <td className="px-4 py-3 font-mono text-slate-600 dark:text-slate-400">{p.nik}</td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{p.position}</td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{p.companies?.name}</td>
                    <td className="px-4 py-3 font-mono text-slate-600 dark:text-slate-400">{p.spk?.spk_number}</td>
                    <td className="px-4 py-3 font-mono text-slate-600 dark:text-slate-400">
                      {p.access_cards?.[0]?.card_number || '-'}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {p.access_cards?.[0]?.expiry_date ? formatDate(p.access_cards[0].expiry_date) : '-'}
                    </td>
                    <td className="px-4 py-3">
                      <span className={getStatusColor(p.access_cards?.[0]?.status || 'ACTIVE')}>
                        {getStatusLabel(p.access_cards?.[0]?.status || 'ACTIVE')}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
