'use client';

import { useEffect, useState } from 'react';
import { apiFetch } from '@/lib/api';
import { formatDate, getStatusColor, getStatusLabel } from '@/lib/utils';
import { Plus, Search, Filter, FileText } from 'lucide-react';
import Link from 'next/link';

interface SPK {
  id: string;
  spk_number: string;
  vendor_name: string;
  work_area: string;
  work_type: string;
  start_date: string;
  end_date: string;
  status: string;
  personnel: { count: number }[];
}

export default function SPKPage() {
  const [spks, setSpks] = useState<SPK[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('');

  useEffect(() => {
    fetchSPKs();
  }, [search, filterStatus]);

  const fetchSPKs = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (search) params.append('search', search);
      if (filterStatus) params.append('status', filterStatus);
      const res = await apiFetch(`/api/spk?${params.toString()}`);
      setSpks(res.data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Data SPK / SHE</h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1">Kelola surat rekomendasi dan SPK vendor</p>
        </div>
        <button className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors">
          <Plus className="w-4 h-4" />
          Tambah SPK
        </button>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-xl border border-border overflow-hidden">
        <div className="p-4 border-b border-border flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Cari nomor SPK..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">Semua Status</option>
            <option value="ACTIVE">Aktif</option>
            <option value="FINISHED">Selesai</option>
            <option value="EXPIRED">Expired</option>
          </select>
        </div>

        {loading ? (
          <div className="p-8 text-center text-slate-500">Memuat data...</div>
        ) : spks.length === 0 ? (
          <div className="p-8 text-center text-slate-500 dark:text-slate-400">
            <FileText className="w-12 h-12 mx-auto mb-3 text-slate-300" />
            <p>Tidak ada data SPK</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 dark:bg-slate-800/50">
                <tr>
                  <th className="px-4 py-3 text-left font-medium text-slate-600 dark:text-slate-400">No SPK</th>
                  <th className="px-4 py-3 text-left font-medium text-slate-600 dark:text-slate-400">Vendor</th>
                  <th className="px-4 py-3 text-left font-medium text-slate-600 dark:text-slate-400">Area</th>
                  <th className="px-4 py-3 text-left font-medium text-slate-600 dark:text-slate-400">Jenis Pekerjaan</th>
                  <th className="px-4 py-3 text-left font-medium text-slate-600 dark:text-slate-400">Mulai</th>
                  <th className="px-4 py-3 text-left font-medium text-slate-600 dark:text-slate-400">Selesai</th>
                  <th className="px-4 py-3 text-left font-medium text-slate-600 dark:text-slate-400">Personel</th>
                  <th className="px-4 py-3 text-left font-medium text-slate-600 dark:text-slate-400">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {spks.map((spk) => (
                  <tr key={spk.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="px-4 py-3 font-mono font-medium text-slate-900 dark:text-white">{spk.spk_number}</td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{spk.vendor_name}</td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{spk.work_area}</td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{spk.work_type}</td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{formatDate(spk.start_date)}</td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{formatDate(spk.end_date)}</td>
                    <td className="px-4 py-3">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-50 text-blue-600 dark:bg-blue-950/30 dark:text-blue-400">
                        {spk.personnel?.[0]?.count || 0} orang
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={getStatusColor(spk.status)}>
                        {getStatusLabel(spk.status)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
