'use client';

import { useEffect, useState } from 'react';
import { usePathname } from 'next/navigation';
import './globals.css';
import { Toaster } from 'react-hot-toast';
import Sidebar from '@/components/layout/sidebar';
import Header from '@/components/layout/header';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const [darkMode, setDarkMode] = useState(false);
  const pathname = usePathname();
  const isLogin = pathname === '/login';

  useEffect(() => {
    const saved = localStorage.getItem('nf_dark');
    if (saved === 'true' || (!saved && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      setDarkMode(true);
      document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleDark = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle('dark');
    localStorage.setItem('nf_dark', String(!darkMode));
  };

  return (
    <html lang="id" className={darkMode ? 'dark' : ''}>
      <body className="bg-background text-foreground antialiased font-sans">
        <Toaster position="top-right" />
        {isLogin ? (
          <main className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950">
            {children}
          </main>
        ) : (
          <div className="flex min-h-screen">
            <Sidebar />
            <div className="flex-1 flex flex-col">
              <Header darkMode={darkMode} toggleDark={toggleDark} />
              <main className="flex-1 p-6 overflow-auto bg-slate-50 dark:bg-slate-950">
                {children}
              </main>
            </div>
          </div>
        )}
      </body>
    </html>
  );
}
