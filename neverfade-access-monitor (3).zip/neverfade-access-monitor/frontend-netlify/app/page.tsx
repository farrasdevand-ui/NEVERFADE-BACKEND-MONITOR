'use client';

import { useEffect, useState } from 'react';
import { apiFetch } from '@/lib/api';
import StatCard from '@/components/dashboard/stat-card';
import AlertTable from '@/components/dashboard/alert-table';
import {
  Activity,
  AlertTriangle,
  CalendarClock,
  CalendarX,
  ShieldAlert,
  Users,
} from 'lucide-react';

interface DashboardStats {
  totalActive: number;
  expiredToday: number;
  expiring14: number;
  expiring7: number;
  expiring3: number;
  toDisable: number;
}

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiFetch('/api/dashboard/stats')
      .then((res) => setStats(res))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Dashboard</h1>
        <p className="text-slate-500 dark:text-slate-400 mt-1">
          Monitoring vendor dan kartu akses real-time
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <StatCard
          title="Vendor Aktif"
          value={stats?.totalActive || 0}
          icon={Users}
          color="blue"
        />
        <StatCard
          title="Expired Hari Ini"
          value={stats?.expiredToday || 0}
          icon={CalendarX}
          color="red"
        />
        <StatCard
          title="H-14"
          value={stats?.expiring14 || 0}
          icon={CalendarClock}
          color="yellow"
        />
        <StatCard
          title="H-7"
          value={stats?.expiring7 || 0}
          icon={AlertTriangle}
          color="orange"
        />
        <StatCard
          title="H-3"
          value={stats?.expiring3 || 0}
          icon={ShieldAlert}
          color="red"
        />
        <StatCard
          title="Disable Hari Ini"
          value={stats?.toDisable || 0}
          icon={Activity}
          color="purple"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <AlertTable type="to-disable" title="Kartu yang Harus Dinonaktifkan Hari Ini" />
        <AlertTable type="expiring" title="Akan Expired (H-14)" />
      </div>
    </div>
  );
}
